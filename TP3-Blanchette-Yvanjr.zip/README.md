# TP3-Blanchette-Yvanjr

#### Description

Site web "responsive" d'un restaurant fictif nommé Delizia Pizzeria en html, css et javascript.

#### Fonctionalitées:

- La navigation mobile est fonctionnelle.

- Le menu du restaurant permet d'ajouter des items dans le "panier" et de storer les données dans le local storage afin de pouvoir simuler une commande en livraison ou pour emporter.

- La page de réservation permet de créer un message de confirmation utilisant les données entrées dans le formulaire de réservation.


https://gitlab.com/techniques-int-gration-web-1/TP3.git
